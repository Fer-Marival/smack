<?php
/**
 * Variables de traducción globales  generales en Inglés
 */
return [

	/* traducciones del nav */
	'home' => 'Home',
	'experiences' => 'Experiences',
	'cameras' => 'Cameras',
	'contact' => 'Contact',

	/* texto de video */
	'rent' => 'Rent',
	'enjoy' => 'Enjoy',
	'know' => 'Know',
	'confort' => 'Confort',

	'rentCamera' => 'a camera',
	'beautifullMoment' => 'beautifull moment',
	'bestPlace' => 'best place',
	'yourTraslate' => 'your traslate',

	/* seección de cuerpo */
	'OurServices' => 'Our Services',
	'rentAcamera' => 'RENT A CAMERA',
	'trips' => 'TRIPS',
	'personalHost' => 'PERSONAL HOST',

	/* Sección de destinos */
	'ourDestiny' => 'Our Destiny',
];