@extends('layouts.app')

@section('content')
<div class="container" id="app">
	
		<first-component></first-component>
	
</div>
@stop