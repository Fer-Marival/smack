<div id="destiny">
    <div class="title">Conoce nuestros destinos</div>
      <div class="slider" id="destiny-slide">
        <div class="sp-slides">
          <div class="sp-slide">
            <a data-fancybox="gallery" href="{!!asset('img/destiny/1.jpg')!!}"><img class="img-fluid" src="{!!asset('img/destiny/1.jpg')!!}"/></a>
            <div class="title">Las Animas </div>     
          </div>
          <div class="sp-slide">
            <a data-fancybox="gallery" href="{!!asset('img/destiny/2.jpg')!!}"><img class="img-fluid" src="{!!asset('img/destiny/2.jpg')!!}"/></a>
            <div class="title">Cerro del  Mono </div>    
          </div>
          <div class="sp-slide">
            <a data-fancybox="gallery" href="{!!asset('img/destiny/3.jpg')!!}"><img class="img-fluid" src="{!!asset('img/destiny/3.jpg')!!}"/></a>
            <div class="title">Palo Maria</div>    
          </div>
        </div>
      </div>
</div>
<div class="container-fluid">
  <div class="title">Agrega una Cámara a tu aventura </div>
  <div id="products">
      <div class="col shadow-flow">
          <div class="content">
            <img src="{!!asset('img/product1.png')!!}" class="img-fluid" alt="">
            One of three columns <br />
            <a href="#" class="rounder">Add to my adveture</a>
          </div>
      </div>
      <div class="col shadow-flow">
        <div class="content">
          <img src="{!!asset('img/product1.png')!!}" class="img-fluid" alt="">
          One of three columns <br />
          <a href="#" class="rounder">Add to my adveture</a>
        </div>
      </div>
      <div class="col shadow-flow">
        <div class="content">
          <img src="{!!asset('img/product1.png')!!}" class="img-fluid" alt="">
          One of three columns <br />
          <a href="#" class="rounder">Add to my adventure</a>
        </div>
      </div>
      <div class="col shadow-flow">
        <div class="content">
            <img src="{!!asset('img/product1.png')!!}" class="img-fluid" alt="">One of three columns <br />
            <a href="#" class="rounder">Add to my adveture</a>
        </div>
      </div>
  </div>
</div>