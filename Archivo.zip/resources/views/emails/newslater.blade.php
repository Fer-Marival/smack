
<h1>Gracias por registrarte a nuestro newslater: {{ $data->email }}</h1>