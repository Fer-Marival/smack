<?php $__env->startSection('content'); ?>

<div class="container">
		<?php echo $__env->make('admin.categories.create', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php if(session()->has('success')): ?>
		    <div class="alert alert-success">
		        <?php echo e(session()->get('success'), false); ?>

		    </div>
		<?php endif; ?>
		<?php if(session()->has('delete')): ?>
		    <div class="alert alert-danger">
		        <?php echo e(session()->get('delete'), false); ?>

		    </div>
		<?php endif; ?>
	<div class="graph-visual tables-main">
		<h2 class="inner-tittle">Categories</h2>
			<div class="graph">
				<div class="tables">
					<table class="table">
					  <thead>
					  	<div class="row">
						  	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addCategory">
							  + Categories
							</button>
					  	</div>
					    <tr>
					      <th><strong>#<strong></th>
					      <th><strong>Name<strong></th>
					      <th><strong>Acciones<strong></th>
					    </tr>
					  </thead>
					  <tbody>
					  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					    <tr>
					      <th><?php echo e($category->id, false); ?></th>
					      <td><?php echo e($category->name, false); ?></td>
					      <td>
						    <a href="<?php echo e(route('categories.edit', $category->id), false); ?>" type="button" class="btn btn-primary"><i class="far fa-edit"></i></a>
					      	<form action="<?php echo e(route('categories.destroy', $category->id), false); ?>" method="post">
				                  <?php echo csrf_field(); ?>
				                  <?php echo method_field('DELETE'); ?>
				                  <button class="btn btn-danger" type="submit"><span class="glyphicon glyphicon-trash"></span></button>
				            </form>
					      </td>
					    </tr>
					  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					  </tbody>
					</table>
			</div>								
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>