<?php $__env->startSection('content'); ?>

<!--/login-->
<div class="error_page">
    <!--/login-top-->                                    
    <div class="error-top">
    <h2 class="inner-tittle page">Augment</h2>
        <div class="login">
        <h3 class="inner-tittle t-inner">Login</h3>
            <div class="buttons login">
                <ul>
                    <li><a href="#" class="hvr-sweep-to-right">Facebook</a></li>
                    <li class="lost"><a href="#" class="hvr-sweep-to-left">Twitter</a> </li>
                    <div class="clearfix"></div>
                </ul>
            </div>
            <form method="POST" action="<?php echo e(route('login'), false); ?>">
                <?php echo csrf_field(); ?>
                <input type="text" class="text form-control<?php echo e($errors->has('email') ? ' is-invalid' : '', false); ?>"  name="email" id="name" required placeholder="E-mail address" value="<?php echo e(old('email'), false); ?>" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'E-mail address';}" >

                <input type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : '', false); ?>" placeholder="Password" name="password" id="password" required onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Password';}">
                    <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('email'), false); ?></strong>
                        </span>
                    <?php endif; ?>
                    <?php if($errors->has('password')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('password'), false); ?></strong>
                        </span>
                    <?php endif; ?>
                <div class="submit"><input type="submit" onclick="myFunction()" value="Login" ></div>
                <div class="clearfix"></div>                                                     
                <div class="new">
                    <p><label class="checkbox11"><input type="checkbox" name="checkbox"><i> </i><a href="<?php echo e(route('password.request'), false); ?>">Forgot Password ?</a></label></p>
                    <p class="sign">Do not have an account ? <a href="sign.html">Sign Up</a></p>
                    <div class="clearfix"></div>
                </div>
            </form>
        </div>                                              
    </div>
</div>

    <!--//login-->
        <!--footer section start-->
        <div class="footer">
            <div class="error-btn">
                <a class="read fourth" href="index.html">Return to Home</a>
            </div>
            <p>&copy 2016 Augment . All Rights Reserved | Design by <a href="https://w3layouts.com/" target="_blank">W3layouts.</a></p>
        </div>
    <!--footer section end-->
    <!--/404-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>