
<h1>Gracias por registrarte a nuestro newslater: <?php echo e($data->email, false); ?></h1>