<?php $__env->startSection('content'); ?>

<div class="container">
		<?php echo $__env->make('admin.products.create', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		
		<?php if(session()->has('success')): ?>
		    <div class="alert alert-success">
		        <?php echo e(session()->get('success'), false); ?>

		    </div>
		<?php endif; ?>

		<?php if(session()->has('delete')): ?>
		    <div class="alert alert-danger">
		        <?php echo e(session()->get('delete'), false); ?>

		    </div>
		<?php endif; ?>
	<div class="graph-visual tables-main">
		<h2 class="inner-tittle">List Users</h2>
			<div class="graph">
				<div class="tables">
					<table class="table">
					  <thead>
					  	<div class="row">
						  	<h3>Products: <?php echo e($total, false); ?></h3>
						  	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addProduct">
							  + product
							</button>
						  	<!--<a href="<?php echo e(route('products.create'), false); ?>" type="button" class="btn btn-primary" id="myModal"> + Product</a> -->
					  	</div>
					    <tr>
					      <th ><strong>#<strong></th>
					      <th><strong>Name<strong></th>
					      <th>Image</th>
					      <th>Category</th>
					      <th>Locale</th>
					      <th>Editar</th>
					      <th>Eliminar</th>
					    </tr>
					  </thead>
					  <tbody>
					  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					    <tr>
					      <th><?php echo e($product->id, false); ?></th>
					      <td><?php echo e($product->name, false); ?></td>
					      <td>
					      	<img width="100px" height="50px" src="<?php echo e(asset($product->image), false); ?>" alt="">
					      </td>
					      <td><?php echo e($product->category_id, false); ?></td>
					      <td><?php echo e($product->locale, false); ?></td>
					      <td >
						    <a href="<?php echo e(route('products.edit', $product->id), false); ?>" type="button" class="btn btn-primary"><i class="far fa-edit"></i></a>
					      </td>
					      <td>
					      	<form action="<?php echo e(route('products.destroy', $product->id), false); ?>" method="post">
				                  <?php echo csrf_field(); ?>
				                  <?php echo method_field('DELETE'); ?>
				                  <button class="btn btn-danger" type="submit"><span class="glyphicon glyphicon-trash"></span></button>
				            </form>
						    
						    
					      </td>
					    </tr>
					  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					  </tbody>
					</table>
			</div>								
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>