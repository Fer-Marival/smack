<header>
	<div class="container">
		<div class="row align-items-center justify-content-between">
			<div class="col-md-2">
				<div class="logo">
					<a href="/"><img src="<?php echo asset('img/logo.svg'); ?>" alt=""></a>
				</div>
			</div>
			<div class="col-md-8">
				<ul class="nav justify-content-end">
				  <li class="nav-item">
				    <a class="nav-link active" href="/"><?php echo app('translator')->getFromJson('global.home'); ?></a>
				  </li>
				  <li class="nav-item">
				    <a class="nav-link" href="/trips"><?php echo app('translator')->getFromJson('global.experiences'); ?></a>
				  </li>
				  <li class="nav-item">
				    <a class="nav-link" href="/cameras"><?php echo app('translator')->getFromJson('global.cameras'); ?></a>
				  </li>
				  <li class="nav-item">
				    <a class="nav-link" href="#"><?php echo app('translator')->getFromJson('global.contact'); ?></a>
				  </li>
				  <li><a href="<?php echo e(url('lang', ['en']), false); ?>">En</a></li>
				  <li><a href="<?php echo e(url('lang', ['es']), false); ?>">Es</a></li>
				</ul>
			</div>
		</div>
	</div>
</header>