<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale()), false); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Smack</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css'), false); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css'), false); ?>">
        
        
    </head>
    <body>
        
    		<?php echo $__env->make('components.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    	  	<?php echo $__env->yieldContent('content'); ?>
    	  	<?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			
        <script src="<?php echo e(asset('js/script.js'), false); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('js/frontend/app.js'), false); ?>" type="text/javascript"></script>
    </body>
</html>
