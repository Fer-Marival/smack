<?php $__env->startSection('content'); ?>
	<div class="container">
		
	    
	        <?php echo Form::model($product, ['route' => ['products.update', $product->id], 'method' => 'PUT']); ?>

	    		<?php echo csrf_field(); ?>
			<div class="row">
	          <div class="form-group col-md-6">
			    <label for="name">Name</label>
			    <?php echo Form::text('name', null,['class' => 'form-control', 'id' => 'name' ]); ?>

			  </div>
			  <div class="form-group col-md-6">
			    <label for="image">Image</label>
			    <input type="file" class="form-control-file" id="image" name="image">
			  </div>
			</div>
			  <div class="form-group">
			    <label for="description">Description</label> 
			    <?php echo Form::textarea('description', null,['class' => 'form-control', 'id' => 'description', 'row' => '3']); ?>

			  </div>
			<div class="row">
			  <div class="form-group col-md-6">
			    <label for="price">Price</label>
			    <?php echo Form::text('price', null,['class' => 'form-control', 'id' => 'price' ]); ?>

			  </div>
			  <div class="form-group col-md-6">
			    <label for="available">Available</label>
			    <?php echo Form::text('available', null,['class' => 'form-control', 'id' => 'available' ]); ?>

			  </div>
			</div>
			<div class="row">
			  <div class="form-group col-md-6">
			  	<label for="category">Category</label>
			      <select id="category" name="category" class="form-control">
			        <option value="1" selected>Artículos</option>
			        <option value="2">Complement</option>
			        <option value="4">Tour Acuaticos</option>
			        <option value="5">Tour Terrestre</option>
			      </select>
		      </div>
		      <div class="form-group col-md-6">
		      <label for="locale">Idioma</label>
			      <select id="locale" name="locale" class="form-control">
			        <option value="en" selected>Inglés</option>
			        <option value="es">Español</option>
			      </select>
		      </div>
		    </div> 
		        <button type="submit" class="btn btn-primary">Save</button>
	      	  
			<?php echo Form::close(); ?>

	</dic>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>