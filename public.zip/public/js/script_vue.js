new Vue({
	el: '#appProduct',
	data: {
		product: 'Producto name',
		listProduct: [],
	method: {

	},
	computed: {
		
	}


	}
});